<?php

 

error_reporting(E_ALL & ~E_NOTICE);

//?custname=customername&custemail=customer@manzelleapp.com&phone=999999999&totAmount=1.500&productnames=Subscription&order_id_app=66666666

include('settings.php');

$custname  = @strip_tags($_REQUEST['custname']);

$custemail = @strip_tags($_REQUEST['custemail']);

$custemobile = @strip_tags($_REQUEST['phone']);

$totAmount =  @strip_tags($_REQUEST['totAmount']);

$productnames =  @strip_tags($_REQUEST['productnames']);

$membership_id =  @strip_tags($_REQUEST['membership_id']);

$user_id =  @strip_tags($_REQUEST['user_id']);

$insid = @strip_tags($_REQUEST['order_id_app']);

$udf1 =  @$insid;

$udf2 =  @$totAmount;

/*

$custname  ='Test customer';

$custemail = 'rejeesh@design-master.com';

$custemobile = '99999';

$totAmount =  '1.500';

$productnames =  'Test product';

$insid =  '15';

$udf1 =  @$insid;

$udf2 =  @$totAmount;*/


$expression = $custname &&   $custemail && $custemobile  && $totAmount  && $productnames && $user_id && $insid ;

 if (empty($expression)   ) {

	$fielderrorurl ='result.php';

	$ResponseMessage ='Transaction not initialized ';

  header("location:".$fielderrorurl."?msg=" . $ResponseMessage); 

  exit();

}  

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL,'https://apidemo.myfatoorah.com/Token');
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array('grant_type' => 'password','username' => $merchantusername,'password' =>$merchantpassword)));
    $result = curl_exec($curl);
    $info = curl_getinfo($curl);
    curl_close($curl);
    $json = json_decode($result, true);
    if(isset($json['access_token']) && !empty($json['access_token'])){
      $access_token= $json['access_token'];
    }else{
    $access_token='';
    }

    if(isset($json['token_type']) && !empty($json['token_type'])){
    $token_type= $json['token_type'];
    }else{
        $token_type='';
    }
    
    
if(isset($json['access_token']) && !empty($json['access_token']))
      {
        echo "Redirecting to Payment Page , Please Wait.<br>";

        $t= time();
        $post_string = '{
            "InvoiceValue": '.$insid.',
            "OrderId": '.$insid.',            
            "CustomerName": "'.$custname.'",
            "CustomerBlock": "",
            "CustomerStreet": "",
            "CustomerHouseBuildingNo": "",
            "CustomerCivilId": "",
            "CustomerAddress": "",
            "CustomerReference": "'.$t.'",
            "DisplayCurrencyIsoAlpha": "KWD",
            "CountryCodeId": "+965",
            "CustomerMobile": "'.$custemobile.'",
            "CustomerEmail": "'.$custemail.'",
            "DisplayCurrencyId": 3,
            "SendInvoiceOption": 1,
            "InvoiceItemsCreate": [
              {
                "ProductId": null,
                "ProductName": "'.$productnames.'",
                "Quantity": 1,
                "UnitPrice": '.$totAmount.'
              }
            ],
           "CallBackUrl":  "'.$returnurl.'",
            "Language": 2,
             "ExpireDate": "2022-12-31T13:30:17.812Z",
            "ApiCustomFileds" : '.$insid.',
  "ErrorUrl": "'.$merchanterrorurl.'"
          }';
        $soap_do     = curl_init();
       curl_setopt($soap_do, CURLOPT_URL, "https://apidemo.myfatoorah.com/ApiInvoices/CreateInvoiceIso");
       curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 10);
       curl_setopt($soap_do, CURLOPT_TIMEOUT, 10);
       curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
       curl_setopt($soap_do, CURLOPT_POST, true);
       curl_setopt($soap_do, CURLOPT_POSTFIELDS, $post_string);
       curl_setopt($soap_do, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8','Content-Length: ' . strlen($post_string),  'Accept: application/json','Authorization: Bearer '.$access_token));
       $result1 = curl_exec($soap_do);
      // echo "<pre>";print_r($result1);die;
       $err    = curl_error($soap_do);
      $json1= json_decode($result1,true);
      $RedirectUrl= $json1['RedirectUrl'];
      $ref_Ex=explode('/',$RedirectUrl);
      $referenceId =  $ref_Ex[4];
       curl_close($soap_do);
	
    echo'<script type="text/javascript">
        window.location="'.$RedirectUrl.'";
    </script>';
    exit('asd');
      }    
  

if ($ResponseCode == 0) {
  if($referenceID){

    date_default_timezone_set('Asia/Kuwait');

    $current_date = date("Y-m-d H:i:s");

    $select = "SELECT * FROM `order_master` WHERE order_master_id='$udf1'";
    $res = db_query($select); 
    $count = mysqli_num_rows($res);
    if($count == 0){

      $insert = "
        INSERT INTO `order_master` (`order_by`, `unique_no`, `package_id`, `sub_package_id`, `delivery_address_id`, `order_status`, `domain_id`, `delivery_datetime`, `package_amount`, `package_for`, `consulatant_fee`, `promo_code_discount`, `payment_amount`, `payment_type`, `created_date`, `last_modified`, `start_date`, `end_date`, `transaction_id`, `created_by`, `is_deleted`)
          VALUES ($user_id, '', 0, '0', '0', 'cancel', '1', '".date('Y-m-d H:i:s')."', '0', '0', '0', '0', 0, 'cash', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."', '0', '$user_id', '0');
      ";              

      $result = db_query($insert);
      header("location:".$paymentUrl."");

      exit();
    
    }else{
      header("location:".$merchanterrorurl."?msg=Invalid unique value");
      exit();
    }
  

  } else{

    header("location:".$merchanterrorurl."?msg=" . $ResponseMessage);

    exit();

  }

} else {

  header("location:".$merchanterrorurl."?msg=" . $ResponseMessage);

  exit();

}	
 
  function db_connect() {

    //enter your MySQL database host name, often it is not necessary to edit this line
    $db_host = "localhost";
    //enter your MySQL database username
    $db_username = "imanag7_muscle_fuel_v1";
    //enter your MySQL database password

    $db_password = "muscle_fuel_v1";
    //enter your MySQL database name
    $db_name = "imanag7_muscle_fuel_v1";


    $connection = mysqli_connect($db_host, $db_username, $db_password, $db_name);
    //mysql_set_charset('utf8',$connection);
    date_default_timezone_set('Asia/Kuwait');

    // If connection was not successful, handle the error
    if ($connection === false) {
        // Handle error - notify administrator, log to a file, show an error screen, etc.
        return mysqli_connect_error();
    } else {
        return $connection;
    }
  }

    function db_query($query) {
        // Connect to the database
        $connection = db_connect();

        // Query the database
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

        return $result;
    }
 

 ?>