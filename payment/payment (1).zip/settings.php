<?php 

 ////////////////  TEST MERCHANT DETAILS/////////  

$merchantcode='999999';

$merchantusername='apiaccount@myfatoorah.com';

$merchantpassword='api12345*';

$url = "https://test.myfatoorah.com/pg/PayGatewayService.asmx"; 

//$url = "https://apidemo.myfatoorah.com/swagger/ui/index#/ApiInvoices"; 

 ////////////////  TEST MERCHANT DETAILS ENDS/////////
 

 ////////////////  LIVE MERCHANT DETAILS/////////

/*$merchantcode='';

$merchantusername='';

$merchantpassword='';

$url = "https://www.myfatoorah.com/pg/PayGatewayService.asmx";  */

 ////////////////  LIVE MERCHANT DETAILS ENDS/////////

$webappname ='MuscleFuel'; 

$webappfromemail= 'no-reply@musclefuelkw.com';  //need to change

$returnurl='http://musclefuel-kw.com/musclefuel/payment/returnFromPayment.php';

$merchanterrorurl='http://musclefuel-kw.com/musclefuel/payment/returnErrorFromPayment.php';    

   

?>